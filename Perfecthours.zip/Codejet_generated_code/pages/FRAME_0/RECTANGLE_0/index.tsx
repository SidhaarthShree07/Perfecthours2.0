export const RECTANGLE = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, -44px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="1382"
      height="927"
      viewBox="0 0 1382 927"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="b0ba178d3268d3c773ec7e98a8c36db89b407949"
          patternUnits="userSpaceOnUse"
          width="1382"
          height="927"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/b0ba/178d/3268d3c773ec7e98a8c36db89b407949?Expires=1693180800&Signature=E71oubfLY1iwb5Nd1z~N3F3HezxFwaatmz86uB4P6T49huF3RufMtTXZlzmwMSWfjulQy8bCEPQeRFGMizT0QUcu5XRRxNONUxHK7u3ZgKtBXO2hrid9j0kcR92WTDZYuLK5u3kN4uyagIFAhjFMeV3prZnLtAgY9RpAJgZPiaHdwUJnHO3HSQqznwdH6HsTio-j5VctubjC1UJfzZg9vOHxfpD47uWq8DCpa7z0g2-pMQrJ9A95PLndA3Y0uO9Dlgv-HJd5l2LjcscNozteVPEIH0DXfSMncLGq-6gMnBYlmDNje8Fc8owhXyGML0BxoKoFlCzNxjnxw6cRA0oJ0A__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="1382"
            height="927"
          />
        </pattern>
      </defs>
      <path
        d="M0 0L1382 0L1382 927L0 927L0 0Z"
        fill="url(#b0ba178d3268d3c773ec7e98a8c36db89b407949)"
      />
    </svg>
  );
};
