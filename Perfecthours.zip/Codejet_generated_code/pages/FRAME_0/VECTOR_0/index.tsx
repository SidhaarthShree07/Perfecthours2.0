export const VECTOR = () => {
  return (
    <svg
      style={{
        transform: "translate(129px, 684px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "28px",
      }}
      width="361"
      height="79"
      viewBox="0 0 361 79"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 28C0 12.536 12.536 0 28 0L333 0C348.464 0 361 12.536 361 28L361 51C361 66.464 348.464 79 333 79L28 79C12.536 79 0 66.464 0 51L0 28Z"
        fill="rgba(44.000001177191734, 5.000000176951289, 114.0000008046627, 1)"
      />
    </svg>
  );
};
