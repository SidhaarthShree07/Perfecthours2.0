import "./style.css";
import { RECTANGLE as RECTANGLE_0 } from "./RECTANGLE_0";
import { VECTOR as VECTOR_0 } from "./VECTOR_0";
import { TEXT } from "components/TEXT";

export const FRAME = () => {
  return (
    <div className="FRAME_1_4">
      <RECTANGLE_0 />
      <VECTOR_0 />
      <TEXT characters="Login" className="TEXT_2_85" />
    </div>
  );
};
